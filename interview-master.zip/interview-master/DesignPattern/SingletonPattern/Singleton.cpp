//
// Created by xiemenghui on 2018/7/20.
//

#include <iostream>
#include "Singleton.h"

void Singleton::DoSomething()
{
    std::cout << "Singleton do something\n";
}